# Ransomware-Samples
Small collection of Ransomware organized by family.please feel free to download, analyze and reverse all the samples in this repository but please let me know the results of your investigation.


<p align="center">
  <img src="ransomware.png" width="300" >
</p>

### ATTENTION
This repository contains actual malware & Ransomware, do not execute any of these files on your pc unless you know exactly what you are doing.

#### password
All 7z and zip files are password protected and the password is "infected" (without quotes).
