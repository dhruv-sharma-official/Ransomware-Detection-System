import time
import threading
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from plyer import notification  # For system notifications
import shutil
import ai
import premiumfolder as backup

# Global variables to control monitoring
observer = None
monitoring = False

# Function to read directory locations from the file
def load_directories_from_file(file_path="monitoring_locations.txt"):
    directories = []
    try:
        with open(file_path, 'r') as file:
            directories = [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        update_status(f"Error: {file_path} not found.")
    return directories

# Function to safely delete a file
def delete_file(file_path):
    try:
        os.remove(file_path)
        update_status(f"File deleted: {file_path}")
    except FileNotFoundError:
        update_status(f"Error: File not found: {file_path}")
    except PermissionError:
        update_status(f"Error: Permission denied when trying to delete: {file_path}")
    except Exception as e:
        update_status(f"Error: Could not delete file {file_path}: {e}")

# Function to trigger a system notification
def send_notification(title, message):
    notification.notify(
        title=title,
        message=message,
        app_name="Malware Detector",
        timeout=10  # Notification stays for 10 seconds
    )

# Function to update status in the status.txt file
def update_status(message):
    with open("status.txt", 'a') as status_file:
        status_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - {message}\n")
    print(message)  # For console output

# Scanner function
def scanner(file_path):
    """Scan the file at the given path and delete if malicious."""
    is_malicious = ai.scanfile(file_path)
    if is_malicious:
        update_status(f"Malicious file detected: {file_path}")
        send_notification("Malicious File Detected", f"File: {file_path}")
        delete_file(file_path)

# Custom event handler class
class MonitorHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if not event.is_directory:
            update_status(f"File modified: {event.src_path}")
            scanner(event.src_path)

    def on_created(self, event):
        if not event.is_directory:
            update_status(f"File created: {event.src_path}")
            scanner(event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            update_status(f"File deleted: {event.src_path}")

    def on_moved(self, event):
        if not event.is_directory:
            update_status(f"File moved from {event.src_path} to {event.dest_path}")
            scanner(event.dest_path)

# Function to start monitoring directories
def start_monitoring():
    global observer, monitoring
    if monitoring:
        update_status("Already monitoring.")
        return

    directories_to_monitor = set(load_directories_from_file())

    if not directories_to_monitor:
        update_status("No directories to monitor. Please check the file.")
        return

    event_handler = MonitorHandler()
    observer = Observer()

    # Function to add a new directory to the observer
    def add_directory_to_observer(directory):
        try:
            observer.schedule(event_handler, path=directory, recursive=True)
            update_status(f"Monitoring: {directory}")
        except Exception as e:
            update_status(f"Failed to monitor directory {directory}: {str(e)}")

    # Monitor initial directories
    for directory in directories_to_monitor:
        add_directory_to_observer(directory)

    observer.start()
    monitoring = True
    update_status("Monitoring started.")

# Function to stop monitoring directories
def stop_monitoring():
    global observer, monitoring
    if observer and monitoring:
        observer.stop()
        observer.join()
        observer = None
        monitoring = False
        update_status("Monitoring stopped.")
    else:
        update_status("No monitoring session to stop.")

# Function to backup files
def backup_files(source_dir, backup_dir):
    try:
        if os.path.exists(source_dir):
            shutil.copytree(source_dir, backup_dir, dirs_exist_ok=True)
            update_status(f"Backup completed from {source_dir} to {backup_dir}")
        else:
            update_status(f"Source directory {source_dir} does not exist.")
    except Exception as e:
        update_status(f"Error during backup: {e}")

# Function to save logs to a file (dummy implementation)
def save_logs(log_file="logs.txt"):
    with open(log_file, 'a') as file:
        file.write("Log entry...\n")  # Replace with actual log entries
    update_status(f"Logs saved to {log_file}.")

# Function to scan a specific file
def scan_file(file_path):
    if os.path.isfile(file_path):
        update_status(f"Scanning file: {file_path}")
        scanner(file_path)
    else:
        update_status(f"Error: {file_path} is not a valid file.")

# Function to process commands from the command file
def process_commands(command_file="command.txt"):
    while True:
        try:
            if os.path.isfile(command_file):
                with open(command_file, 'r') as file:
                    commands = [line.strip() for line in file.readlines() if line.strip()]

                for command in commands:
                    if command == "START_MONITORING":
                        start_monitoring()
                    elif command == "STOP_MONITORING":
                        stop_monitoring()
                    elif command == "savelogs":
                        save_logs()
                    elif command.startswith("backup"):
                        backup.create_incremental_backup()
                    elif command.startswith("scanfile"):
                        _, file_path = command.split(maxsplit=1)
                        scan_file(file_path)
                    else:
                        update_status(f"Unknown command: {command}")

                # Clear commands after processing
                open(command_file, 'w').close()

            time.sleep(5)  # Check for commands every 5 seconds
        except Exception as e:
            update_status(f"Error processing commands: {e}")

if __name__ == "__main__":
    # Start the command processing thread
    command_thread = threading.Thread(target=process_commands, daemon=True)
    command_thread.start()

    # Keep the script running
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_monitoring()
        update_status("Program terminated.")
